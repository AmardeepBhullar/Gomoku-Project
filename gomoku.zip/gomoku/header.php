<header>
    <div class="headerSec-1">
        <div id="title">
            <a href="index.php">
                <h1>Gomoku</h1>
            </a>
        </div>
    </div>
    <div class="headerSec-2">
        <div class="nav">
            <ul class="navLinks">
                <?php 
                
                    if(isset($_SESSION['user'])){
                        echo '<li class="link"><a class="link-a" href="index.php">Home</a></li>
                        <li class="link"><a class="link-a" href="game.php">Game</a></li>
                        <li class="link"><a class="link-a" href="contact.php">Contact</a></li>
                        <li class="link"><a class="link-a" href="help.php">Help</a></li>
                        <li class="link"><a class="link-a" href="leaderboard.php">Leaderboard</a></li>
                        <li class="link"><a class="link-a" href="?logout=">logout</a></li>';
                    }else{
                        echo '<li class="link"><a class="link-a" href="login.php">Login</a></li>
                        <li class="link"><a class="link-a" href="register.php">Register</a></li>
                        ';
                    }
                
                ?>
            </ul>
        </div>
    </div>
</header>
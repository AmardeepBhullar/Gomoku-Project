CSCI 130
PROJECT GOMOKU
Group(Amardeep Bhullar, Pranav Arora)

How to open the project.

Install the Xampp using the this link https://www.apachefriends.org/download.html

After install the Xampp on your computer unzip the gomoku file in the htdocs folder located in Xampp files.

After completing the above step open http://localhost/phpmyadmin in the browser

In this we have to create the database first by simply clicking on the database tab on left and hit create and then upload the Gomoku folder stored in xampp files 

Once the folder is created hit go in the bottom and a new database named Gomoku will be created.
Now type http://localhost/gomoku in the browser



Gomoku is game, also called Five in a Row, is an abstract strategy board game. It is traditionally played 
with Go pieces (black and white stones) on a Go board.  

https://en.wikipedia.org/wiki/Gomoku 
It is played using a 15×15 board while in the past a 19×19 board was standard

RULES

Players alternate turns placing a stone of their color on an empty intersection (using the mouse). Black 
plays first. The winner is the first player to form an unbroken chain of five stones horizontally, vertically, 
or diagonally. Placing so that a line of more than five stones of the same color is created does not result 
in a win.  
The game is played with 2 players on the same screen. We will consider that the player who is logged 
into the game will be the first player (black). The second player (white) will be played by another person 
on the same machine, same screen.  
At the end of the game, we will only record the information from Player 1. 
At the end of each game, the score, the duration of the game, and the number of turns will be saved in 
the RDBMS on the server side, so they can be displayed in the leaderboard page. The server side will be 
only used to save the results of each game, keep information about Player 1. 

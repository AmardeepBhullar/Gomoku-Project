<?php require_once 'utils.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <?php require_once 'header.php'; ?>
    <main>
        <div id="menu">
            <div id="menus" style="margin-top: 89px;">
                <div class="login-page">
                    <?php

                    if (isset($_SESSION['msg'])) {
                        $msg = $_SESSION['msg'];
                        echo "<p id='msg'>$msg</p>";
                        unset($_SESSION['msg']);
                    }
                    ?>
                    <div class="form">
                        <form method='post' action='utils.php' class="register-form">
                            <input required type="text" name='name' placeholder="username" />
                            <input required type="email" name='email' placeholder="email address" />
                            <input required type="password" name='pass' placeholder="password" />
                            <button type="submit" name='signup'>signup</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer></footer>
</body>

</html>
let ROWS_COUNT = 15;
let COLUMNS_COUNT = 15;
const WIN_SEQUENCE_LENGTH = 5;
let currentTurn = "black";
let turns = 1;
let second = 0;
const minutes = document.getElementById("minutes");
const seconds = document.getElementById("seconds");
const stopwatch = {
  second: 0,
  start: function () {
    if (!this.interval) {
      const self = this;
      function count(val) {
        return val > 9 ? val : "0" + val;
      }
      this.interval = setInterval(function () {
        self.second += 1;
        seconds.innerHTML = count(++second % 60);
        minutes.innerHTML = count(parseInt(second / 60, 10));
      }, 1000);
    }
  },
  pause: function () {
    clearInterval(this.interval);
    delete this.interval;
  },
};

const setScore = (player) => {
  let target = document.getElementById(player.color);
  if (target) {
    target.innerHTML = parseInt(target.innerHTML) + 1;
    generateBoard();
  }
};

const generateBoard = () => {
  class Chip {
    constructor(chipNode, rowIndex, columnIndex) {
      this.node = chipNode;
      this.rowIndex = rowIndex;
      this.columnIndex = columnIndex;
      this.node.addEventListener("click", () => {
        const targetChip = chips.chips[this.rowIndex][this.columnIndex];
        if (!targetChip.color) {
          targetChip.setColor(currentTurn);
          turns += 1;
          const winChips = getWinChips(targetChip);
          if (winChips.length !== 0) {
            setScore(targetChip);
          }
          switchTurn();
        }
      });
    }

    setColor(color) {
      this.color = color;
      this.node.innerHTML = `<p class='currentTurns' style='color:${
        color == "black" ? "white" : "black"
      }'>${turns}</>`;
      const oldClassAttribute = this.node.getAttribute("class");
      const colorsRegExp = /black|white|red/;
      this.node.setAttribute(
        "class",
        colorsRegExp.test(oldClassAttribute)
          ? oldClassAttribute.replace(colorsRegExp, color)
          : `${oldClassAttribute} ${color}`
      );
    }
  }

  class ChipsCollection {
    constructor({ rows, columns }) {
      this.rowsCount = rows;
      this.columnsCount = columns;
      this.chips = [[]]; //store chips in two-dimensional array
    }

    push(chipNode) {
      const lastRow = this.chips[this.chips.length - 1];
      const rowIndex = this.chips.length - 1;
      const columnIndex = lastRow.length;
      if (lastRow.length < this.columnsCount) {
        const chip = new Chip(chipNode, rowIndex, columnIndex);
        lastRow.push(chip);
      } else {
        if (this.chips.length < this.rowsCount) {
          const chip = new Chip(chipNode, rowIndex + 1, 0);
          const newRow = [chip];
          this.chips.push(newRow);
        }
      }
    }
  }

  let chips = new ChipsCollection({
    rows: ROWS_COUNT + 1,
    columns: COLUMNS_COUNT + 1,
  });

  const table = document.getElementById("field-table");
  table.innerHTML = "";
  let chipCounter = 0;
  for (let y = 0; y < ROWS_COUNT; y++) {
    const row = document.createElement("tr");
    for (let x = 0; x < COLUMNS_COUNT; x++) {
      const cell = document.createElement("td");
      createChipInCell(cell);
      const lastCellInRow = x === COLUMNS_COUNT - 1;
      if (lastCellInRow) {
        createChipInCell(cell, "last-in-row");
      }
      row.appendChild(cell);
    }
    table.appendChild(row);
  }

  document
    .querySelectorAll("#field-table tr:last-child td")
    .forEach((cell, index) => {
      const lastCellInRow = index === COLUMNS_COUNT - 1;
      createChipInCell(cell, "last-in-column");
      if (lastCellInRow) {
        createChipInCell(cell, "last-in-row", "last-in-column");
      }
    });

  function createChipInCell(cellNode, ...additionalChipClasses) {
    const chipNode = document.createElement("div");
    chips.push(chipNode);
    chipNode.setAttribute("class", "chip");
    additionalChipClasses.forEach((additionalClass) => {
      chipNode.setAttribute(
        "class",
        chipNode.getAttribute("class") + " " + additionalClass
      );
    });
    cellNode.appendChild(chipNode);
  }

  function switchTurn() {
    currentTurn === "white" ? (currentTurn = "black") : (currentTurn = "white");
  }

  function getWinChips(targetChip) {
    const horisontalWinSequence = getHorisontalWinSequence(targetChip);
    const verticalWinSequence = getVerticalWinSequence(targetChip);
    const slashWinSequence = getSlashWinSequence(targetChip);
    const backSlashWinSequence = getBackSlashWinSequence(targetChip);
    return [
      ...horisontalWinSequence,
      ...verticalWinSequence,
      ...slashWinSequence,
      ...backSlashWinSequence,
    ];
  }

  function getHorisontalWinSequence(targetChip) {
    let chipSequences = [];
    let currentChipSequence = [];
    for (let y = targetChip.rowIndex, x = 0; x < chips.columnsCount; x++) {
      if (chips.chips[y][x].color === currentTurn) {
        currentChipSequence.push(chips.chips[y][x]);
        if (x === chips.columnsCount - 1) {
          chipSequences.push([...currentChipSequence]);
        }
      } else if (currentChipSequence.length) {
        chipSequences.push([...currentChipSequence]);
        currentChipSequence = [];
      }
    }
    const winSequence =
      chipSequences.find(
        (sequence) => sequence.length >= WIN_SEQUENCE_LENGTH
      ) || [];
    return winSequence;
  }

  function getVerticalWinSequence(targetChip) {
    let chipSequences = [];
    let currentChipSequence = [];
    for (let y = 0, x = targetChip.columnIndex; y < chips.rowsCount; y++) {
      if (chips.chips[y][x].color === currentTurn) {
        currentChipSequence.push(chips.chips[y][x]);
        if (y === chips.rowsCount - 1) {
          chipSequences.push([...currentChipSequence]);
        }
      } else if (currentChipSequence.length) {
        chipSequences.push([...currentChipSequence]);
        currentChipSequence = [];
      }
    }
    const winSequence =
      chipSequences.find(
        (sequence) => sequence.length >= WIN_SEQUENCE_LENGTH
      ) || [];
    return winSequence;
  }

  function getSlashWinSequence(targetChip) {
    let chipSequences = [];
    let currentChipSequence = [];
    const coordinatesSum = targetChip.rowIndex + targetChip.columnIndex;
    const startY =
      coordinatesSum < chips.rowsCount - 1
        ? coordinatesSum
        : chips.rowsCount - 1;
    const startX =
      coordinatesSum >= chips.rowsCount - 1
        ? coordinatesSum - (chips.rowsCount - 1)
        : 0;
    for (
      let y = startY, x = startX;
      x < chips.columnsCount && y >= 0;
      x++, y--
    ) {
      if (chips.chips[y][x].color === currentTurn) {
        currentChipSequence.push(chips.chips[y][x]);
        if (x === chips.columnsCount - 1 || y === 0) {
          chipSequences.push([...currentChipSequence]);
        }
      } else if (currentChipSequence.length) {
        chipSequences.push([...currentChipSequence]);
        currentChipSequence = [];
      }
    }
    const winSequence =
      chipSequences.find(
        (sequence) => sequence.length >= WIN_SEQUENCE_LENGTH
      ) || [];
    return winSequence;
  }

  function getBackSlashWinSequence(targetChip) {
    let chipSequences = [];
    let currentChipSequence = [];
    const coordinatesDifference = targetChip.rowIndex - targetChip.columnIndex;
    const startY = coordinatesDifference > 0 ? coordinatesDifference : 0;
    const startX =
      coordinatesDifference > 0 ? 0 : Math.abs(coordinatesDifference);

    for (
      let y = startY, x = startX;
      x < chips.columnsCount && y < chips.rowsCount;
      x++, y++
    ) {
      if (chips.chips[y][x].color === currentTurn) {
        currentChipSequence.push(chips.chips[y][x]);
        if (x === chips.columnsCount - 1 || y === chips.rowsCount - 1) {
          chipSequences.push([...currentChipSequence]);
        }
      } else if (currentChipSequence.length) {
        chipSequences.push([...currentChipSequence]);
        currentChipSequence = [];
      }
    }
    const winSequence =
      chipSequences.find(
        (sequence) => sequence.length >= WIN_SEQUENCE_LENGTH
      ) || [];
    return winSequence;
  }
};

const handleSubmit = (event) => {
  event.preventDefault();

  size = document.getElementById("size");
  color = document.getElementById("color");
  ROWS_COUNT = parseInt(size.value);
  COLUMNS_COUNT = parseInt(size.value);
  generateBoard();
  if (color) {
    document.getElementById("canvas").style.backgroundColor = color.value;
  }
  document.getElementById("setup-modal").style.display = "none";
  stopwatch.start();
};

const handleStop = () => {
  stopwatch.pause();
  let score = document.getElementById('black').innerHTML;
  let time = parseInt(minutes.innerHTML);
  $.ajax({
    type: "POST",
    url: "utils.php",
    data: { score,time },
    success: (data) => {
      alert(data);
    },
    error: (data) => {
      console.log(data);
    },
  })
};

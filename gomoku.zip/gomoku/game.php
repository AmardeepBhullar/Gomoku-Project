<?php require_once 'utils.php';
if (!isset($_SESSION['user'])) {
    redirect('login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <?php require_once 'header.php'; ?>
    <main>
        <div id='game-container'>
            <div class="field" id='canvas'>
                <table id="field-table"></table>
            </div>
            <div class="game-settings">
                <div class="game-buttons">
                    <div class="seconds-counter" style="font-size: 30px;"><span id="seconds-counter"><label id="minutes">00</label>:<label id="seconds">00</label></span></div>
                    <button onclick="window.location.reload()">Restart</button>
                    <button onclick="handleStop()">Stop</button>
                </div>
                <h3>Player 1 : <span id='black'>0</span></h3>
                <h3>Player 2 : <span id='white'>0</span></h3>
            </div>
        </div>


    </main>
    <div class="modal-background" style="display: block !important;" id="setup-modal">
      <form id="setup-form">
        <h2>Game Settings</h2>
        <h3>Customize</h3>
        <div class="option-div">
          <div>
            <label for="human">Board Size</label>
            <input  type="text" id="size" value='15' required>
          </div>
        </div>
        <div class="option-div">
            <div>
            <label style="white-space: nowrap;" for="human">Board Color (hex code / color name)</label>
            <input  type="text" id="color" value='' required>
          </div>
        </div>
        
        
        <input type="submit" onclick="handleSubmit(event)"  value="Start Game">
      </form>
    </div>

    <footer></footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="js/main.js"></script>
</body>

</html>
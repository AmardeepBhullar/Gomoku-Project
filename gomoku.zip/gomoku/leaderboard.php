<?php require_once 'utils.php';
if (!isset($_SESSION['user'])) {
    redirect('login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <?php require_once 'header.php'; ?>
    <main>
        <div class="menu">
            <?php if(count($leaderLists)>0):?>
            <div class="all_leader">
                <h1>All user Leaderboard</h1>
                <table>
                    <tr>
                        <th>User</th>
                        <th>Total Time</th>
                        <th>No of games</th>
                    </tr>
                    <?php 


                        for($i=0;$i<count($leaderLists);$i++){
                            $info = $leaderLists[$i];
                            $name = $info['name'];
                            $time = $info['total_time'] == 0 ? 1 : $info['total_time'];
                            $games = $info['no_games'];
                            echo "<tr><td>$name</td>
                            <td>$time Min</td>
                            <td>$games</td></tr>";
                        }
                    ?>
                </table>
            </div>
            <?php endif;?>
            <?php if($playlist ->num_rows > 0) :?>
            <div class="user_playlist">
                <div id='playlist'>
                    <h1><?php echo $username;?> Play list</h1>
                    <table>
                        <tr>
                            <th>Game</th>
                            <th>Score</th>
                            <th>Duration</th>
                        </tr>
                        <?php 
                            $count = 0;
                            while($data = $playlist->fetch_array()){
                                $count +=1; 
                                $score = $data['score'];
                                $duration = $data['duration'] == 0 ? 1 : $data['duration'];;
                                echo "<tr><td>Game - $count</td>
                                <td>$score</td>
                                <td>$duration Min</td></tr>";
                            }                    
                        ?>
                    </table>
                </div>
            </div>
            <?php endif;?>
        </div>
    </main>


    <footer></footer>
    <script src="js/main.js"></script>
</body>

</html>
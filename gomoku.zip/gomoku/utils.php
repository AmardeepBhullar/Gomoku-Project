<?php 
    $hn = 'localhost';
    $db = 'gomoku';
    $un= 'root';
    $pw= '';

    $conn = new mysqli($hn,$un,$pw,$db); 
    if ($conn ->connect_error) die ($conn->connect_error);

    session_start();

    $username = '';



    function redirect($newURL){
        header("Location: $newURL");
        die();
    }

    if(isset($_SESSION['user'])){
        $email = $_SESSION['user'];
        $user_q = $conn->query('SELECT * from users WHERE email="'.$email.'"');
        if(!$user_q) die ($conn->error);
        if($user_q->num_rows > 0){
            $data = $user_q->fetch_array();
            $username = $data['name'];
            $userid = $data['id'];

            $user_q_2 = $conn->query('SELECT * from leaderboard WHERE user="'.$userid.'"');
            if(!$user_q_2) die ($conn->error);
            $playlist = $user_q_2;
        }

        $userlists = $conn->query('SELECT * from users');
        if(!$userlists) die ($conn->error);

        if($userlists->num_rows > 0){
            $leaderLists = [];
            while($data=$userlists->fetch_array()){
                $userid = $data['id'];
                $name = $data['name'];
                $time_count = 0;
                $no_games = 0;
                $score = 0;

                $lists = $conn->query('SELECT * from leaderboard WHERE user="'.$userid.'"');
                if(!$lists) die ($conn->error);

                if($lists->num_rows >0){
                    while($data_2 = $lists->fetch_array()){
                        $no_games +=1;
                        $time_count += $data_2['duration'];
                        $score += $data_2['score'];
                    }
                    $leaderInfo = array("score"=>$score,"name"=>$name,"total_time"=>$time_count,"no_games"=>$no_games);
                    array_push($leaderLists,$leaderInfo);
                }
                

            }
            
        }


        
    }

    if(isset($_POST['signup'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        
        $query = $conn->query('SELECT * from users WHERE (email="'.$email.'" or name="'.$name.'")');
        if(!$query) die ($conn->error);
        if($query -> num_rows <= 0){
            
            $add_user = $conn->query("INSERT INTO users (name,email,pass) VALUES ('$name','$email','$pass')");
            if(!$add_user) die ($conn->error);
            $_SESSION['msg'] = 'Account has created';
            redirect('login.php');

        }else{
            $_SESSION['msg'] = 'user already exist!';
            redirect('register.php');
        }
    }

    if(isset($_GET['logout'])){
        unset($_SESSION['user']);
        redirect('login.php');
    }

    if(isset($_POST['login'])){
        $email = $_POST['email'];
        $pass = $_POST['pass'];

        $query = $conn->query('SELECT * from users WHERE (email="'.$email.'" and pass="'.$pass.'")');
        if(!$query) die ($conn->error);

        if($query->num_rows > 0){
            $_SESSION['user'] = $email;
            redirect('index.php');
        }else{
            $_SESSION['msg'] = 'No active account found!';
            redirect('login.php');
        }

    }


    if(isset($_POST['score'])){
        $email = $_SESSION['user'];
        $score = $_POST['score'];
        $duration = $_POST['time'];

        $user_q = $conn->query('SELECT * from users WHERE email="'.$email.'"');
        if(!$user_q) die ($conn->error);
        if($user_q->num_rows > 0){
            $data = $user_q->fetch_array();
            $userId = $data['id'];
            $leaderBoard_q = $conn->query("INSERT INTO leaderboard (user,score,duration) VALUES ('$userId','$score','$duration')");

            if(!$leaderBoard_q) die ($conn->error);

            echo "Game details has saved";


        }
    }

?>
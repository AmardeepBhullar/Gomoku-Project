<?php require_once 'utils.php';
if (!isset($_SESSION['user'])) {
    redirect('login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <?php require_once 'header.php'; ?>
    <main>
        <div class="menu">
            <div class="contact">
                <h1>Authors</h1>
                <p>Pranav Arora: 110663117 </p>
                <br>
                <p>Amardeep Singh: 109963782</p>
            </div>
        </div>
    </main>
    <footer></footer>
</body>

</html>

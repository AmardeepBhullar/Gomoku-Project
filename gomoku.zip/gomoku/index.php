<?php require_once 'utils.php';
if (!isset($_SESSION['user'])) {
    redirect('login.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <?php require_once 'header.php'; ?>
    <div class="hero-image">
        <div class="hero-text">
            <h1>Welcome to Gomoku Game</h1>
            <a href="game.php" id="startGame">Start</a>
        </div>
    </div>
    <footer></footer>
</body>

</html>